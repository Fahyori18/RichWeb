using the extension I was able to access element of the DOM
such as the span and the body of the page and manipulate their values 
after the HTML was already loaded. Allowing things like all images being 
changed and the links being changed and the css changing too.